package net.oxisi.autosorter;

import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.entity.ArmorStand;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.IronGolem;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDeathEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.scheduler.BukkitRunnable;

public class GolemDeathListener implements Listener {

    private final AutoSorter plugin;

    public GolemDeathListener(AutoSorter plugin) {
        this.plugin = plugin;
    }

    @EventHandler
    public void onGolemDeath(EntityDeathEvent event) {
        if (event.getEntity() instanceof IronGolem) {
            IronGolem golem = (IronGolem) event.getEntity();
            Location loc = golem.getLocation().add(0, 1, 0);

            ArmorStand smallStand = (ArmorStand) loc.getWorld().spawnEntity(loc, EntityType.ARMOR_STAND);
            smallStand.setVisible(false);
            smallStand.setGravity(false);
            smallStand.setSmall(true);

            ArmorStand normalStand = (ArmorStand) loc.getWorld().spawnEntity(loc, EntityType.ARMOR_STAND);
            normalStand.setVisible(false);
            normalStand.setGravity(false);

            ItemStack glass = new ItemStack(Material.RED_STAINED_GLASS);
            smallStand.setHelmet(glass);


            new BukkitRunnable() {
                double angle = 0;
                int tick = 0;

                @Override
                public void run() {
                    angle += Math.PI / 20;
                    tick++;

                    if (angle > Math.PI * 2) {
                        angle -= Math.PI * 2;
                    }
                    
                    Location smallLoc = smallStand.getLocation();
                    Location normalLoc = normalStand.getLocation();
                    smallLoc.setYaw((float) Math.toDegrees(angle));
                    normalLoc.setYaw((float) Math.toDegrees(angle));
                    smallStand.teleport(smallLoc);
                    normalStand.teleport(normalLoc);

                    if (tick >= 30) {
                        smallStand.remove();
                        normalStand.setHelmet(glass);
                    }

                    if (tick >= 60) {
                        normalStand.remove();
                        this.cancel();
                    }
                }
            }.runTaskTimer(plugin, 0L, 1L);
        }
    }
}

